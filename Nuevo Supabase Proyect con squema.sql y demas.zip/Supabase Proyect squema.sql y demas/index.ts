import { createClient } from "jsr:@supabase/supabase-js@2";
import { SMTPClient } from "https://deno.land/x/denomailer@1.6.0/mod.ts";

const corsHeaders = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Headers": "authorization, x-client-info, apikey, content-type, x-cron-secret",
  "Access-Control-Allow-Methods": "POST, OPTIONS",
};

function json(body: unknown, status = 200) {
  return new Response(JSON.stringify(body), {
    status,
    headers: { "Content-Type": "application/json", ...corsHeaders },
  });
}

// Secreto compartido para llamadas internas desde la base de datos (pg_cron).
// Debe coincidir con el valor usado en las funciones SQL enviar_recordatorios_*.
// ⚠️ REEMPLAZAR: generar un valor nuevo para el proyecto recreado y usar el
// mismo valor en las funciones SQL que llaman a este edge function (ver
// schema.sql, funciones enviar_recordatorios_*). No reutilizar el secreto
// del proyecto original.
const CRON_SECRET = "REEMPLAZAR_CRON_SECRET";

Deno.serve(async (req: Request) => {
  if (req.method === "OPTIONS") {
    return new Response("ok", { headers: corsHeaders });
  }

  try {
    const supabaseAdmin = createClient(
      Deno.env.get("SUPABASE_URL")!,
      Deno.env.get("SUPABASE_SERVICE_ROLE_KEY")!
    );

    // Dos formas de autorizar el envío:
    //  a) llamada interna desde la base de datos (cron / triggers), que manda
    //     un secreto compartido en el header x-cron-secret. No hay usuario
    //     logueado en este caso, así que no chequeamos rol.
    //  b) llamada desde el frontend con la sesión de un admin logueado.
    const cronSecret = req.headers.get("x-cron-secret");
    const esLlamadaInterna = !!cronSecret && cronSecret === CRON_SECRET;

    if (!esLlamadaInterna) {
      const authHeader = req.headers.get("Authorization");
      if (!authHeader) return json({ error: "No autorizado" }, 401);

      const token = authHeader.replace("Bearer ", "");
      const { data: { user }, error: authError } = await supabaseAdmin.auth.getUser(token);
      if (authError || !user) return json({ error: "No autorizado" }, 401);

      const { data: perfilSolicitante } = await supabaseAdmin
        .from("profiles")
        .select("rol")
        .eq("id", user.id)
        .maybeSingle();

      if (perfilSolicitante?.rol !== "admin") {
        return json({ error: "Solo un administrador puede enviar notificaciones" }, 403);
      }
    }

    const { userIds, asunto, mensaje } = await req.json();

    if (!Array.isArray(userIds) || !asunto || !mensaje) {
      return json({ error: "Faltan userIds, asunto o mensaje" }, 400);
    }

    // Los ids recibidos pueden ser:
    //  a) profiles.id (= auth.users.id), como manda Limpieza.jsx via grupo_id
    //  b) publicadores.id, como mandan VidaMinisterio.jsx y ReunionPublica.jsx
    // Resolución en 3 pasos:
    //  1) probamos como id de auth directo
    //  2) si no hay email, lo resolvemos como publicador_id buscando el profile
    //     vinculado (si existe cuenta de login)
    //  3) si tampoco hay cuenta de login, buscamos publicadores.email directo
    //     (permite notificar a publicadores sin cuenta en la app)
    const emails: string[] = [];
    let sinCuenta = 0;
    let sinContacto = 0;

    for (const id of userIds) {
      let email: string | undefined;

      const directo = await supabaseAdmin.auth.admin.getUserById(id);
      email = directo.data?.user?.email;

      if (!email) {
        const { data: perfil } = await supabaseAdmin
          .from("profiles")
          .select("id")
          .eq("publicador_id", id)
          .maybeSingle();

        if (perfil?.id) {
          const viaPublicador = await supabaseAdmin.auth.admin.getUserById(perfil.id);
          email = viaPublicador.data?.user?.email;
        }
      }

      if (!email) {
        sinCuenta++;
        const { data: publicador } = await supabaseAdmin
          .from("publicadores")
          .select("email")
          .eq("id", id)
          .maybeSingle();

        if (publicador?.email) email = publicador.email;
      }

      if (email) emails.push(email);
      else sinContacto++;
    }

    if (emails.length === 0) {
      return json({ enviados: 0, sinCuenta, sinContacto, motivo: "sin destinatarios con email disponible" }, 200);
    }

    const smtpHost = Deno.env.get("SMTP_HOST")!;
    const smtpPort = Number(Deno.env.get("SMTP_PORT")!);
    const smtpUser = Deno.env.get("SMTP_USER")!;
    const smtpPassword = Deno.env.get("SMTP_PASSWORD")!;

    const client = new SMTPClient({
      connection: {
        hostname: smtpHost,
        port: smtpPort,
        tls: smtpPort === 465,
        auth: { username: smtpUser, password: smtpPassword },
      },
    });

    await client.send({
      from: smtpUser,
      to: emails,
      subject: asunto,
      content: mensaje,
      html: `<p>${mensaje.replace(/\n/g, "<br/>")}</p>`,
    });

    await client.close();

    return json({ enviados: emails.length, sinCuenta, sinContacto }, 200);
  } catch (err) {
    console.error(err);
    return json({ error: String(err) }, 500);
  }
});
