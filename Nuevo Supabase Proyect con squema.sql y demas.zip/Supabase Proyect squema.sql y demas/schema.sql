-- =====================================================================
-- VidaMinisterio — Reconstrucción completa del esquema de Supabase
-- Proyecto origen: hkqfaihwhyrfgshzhvue
-- Generado a partir del proyecto EN VIVO (no del zip, que no traía SQL)
-- =====================================================================
-- ORDEN DE EJECUCIÓN:
--   1. Este archivo completo, en un proyecto Supabase nuevo y vacío
--      (SQL Editor -> pegar todo -> Run). Ya está ordenado correctamente
--      (extensiones -> enums -> tablas -> funciones -> triggers -> RLS -> grants -> cron)
--   2. Desplegar las 3 edge functions (wol-importar, notificar, gestionar-cuentas)
--   3. Configurar los secrets manualmente (ver sección final de este archivo)
-- =====================================================================

-- ---------------------------------------------------------------------
-- 1. EXTENSIONES
-- ---------------------------------------------------------------------
create extension if not exists pgcrypto with schema extensions;
create extension if not exists pg_net with schema extensions;
create extension if not exists pg_cron with schema extensions;

-- ---------------------------------------------------------------------
-- 2. ENUMS
-- ---------------------------------------------------------------------
create type public.rol_usuario as enum ('admin','anciano','publicador','siervo_ministerial');

create type public.seccion_reunion as enum ('tesoros','ministerio','vida_cristiana');

create type public.tipo_servicio_publicador as enum (
  'publicador','precursor_auxiliar','precursor_regular',
  'precursor_especial','siervo_ministerial','anciano'
);

-- ---------------------------------------------------------------------
-- 3. TABLAS
-- ---------------------------------------------------------------------

create table public.grupos (
  id uuid primary key default gen_random_uuid(),
  nombre text not null,
  encargado_id uuid, -- fk a publicadores, se agrega después
  created_at timestamptz default now()
);

create table public.publicadores (
  id uuid primary key default gen_random_uuid(),
  nombre text not null,
  direccion text,
  telefono text,
  numero_documento text,
  cpf text,
  servicio public.tipo_servicio_publicador not null default 'publicador',
  activo boolean not null default true,
  notas text,
  creado_en timestamptz not null default now(),
  email text,
  grupo_id uuid references public.grupos(id)
);

alter table public.grupos
  add constraint grupos_encargado_id_fkey foreign key (encargado_id) references public.publicadores(id);

create table public.profiles (
  id uuid primary key references auth.users(id),
  nombre text,
  rol public.rol_usuario not null default 'publicador',
  created_at timestamptz not null default now(),
  aprobado boolean not null default false,
  publicador_id uuid references public.publicadores(id)
);

create table public.config_congregacion (
  id integer primary key default 1 check (id = 1),
  nombre text not null default 'Mi Congregación',
  direccion text,
  dia_reunion_publica text,
  hora_reunion_publica text,
  dia_vida_ministerio text,
  hora_vida_ministerio text,
  telefono_contacto text,
  logo_url text,
  actualizado_at timestamptz default now()
);

create table public.salidas_predicacion (
  id uuid primary key default gen_random_uuid(),
  grupo_id uuid references public.grupos(id),
  fecha date not null,
  hora time,
  punto_encuentro text,
  encargado_id uuid references public.publicadores(id),
  notas text,
  created_at timestamptz default now()
);

create table public.semanas_vida_ministerio (
  id uuid primary key default gen_random_uuid(),
  fecha_inicio date not null unique,
  cantico_inicial text,
  cantico_final text,
  presidente_id uuid references public.publicadores(id),
  oracion_inicial_id uuid references public.publicadores(id),
  oracion_final_id uuid references public.publicadores(id),
  created_at timestamptz default now(),
  lectura_biblia text
);

create table public.partes_vida_ministerio (
  id uuid primary key default gen_random_uuid(),
  semana_id uuid references public.semanas_vida_ministerio(id),
  seccion public.seccion_reunion not null,
  orden integer not null default 0,
  titulo text not null,
  duracion_min integer,
  asignado_id uuid references public.publicadores(id),
  ayudante_id uuid references public.publicadores(id),
  notas text,
  sala text check (sala = any (array['A','B'])),
  es_lectura_biblia boolean not null default false
);

create table public.reuniones_publicas (
  id uuid primary key default gen_random_uuid(),
  fecha date not null unique,
  tema text,
  orador_nombre text,
  congregacion_visitante text,
  presidente_id uuid references public.publicadores(id),
  conductor_atalaya_id uuid references public.publicadores(id),
  lector_id uuid references public.publicadores(id),
  notas text,
  created_at timestamptz default now(),
  numero_discurso text,
  orador_id uuid references public.publicadores(id)
);

create table public.turnos_limpieza (
  id uuid primary key default gen_random_uuid(),
  fecha_inicio date not null,
  fecha_fin date not null,
  responsable_id uuid references public.publicadores(id),
  notas text,
  created_at timestamptz default now(),
  grupo_id uuid references public.grupos(id)
);

create table public.anuncios (
  id uuid primary key default gen_random_uuid(),
  titulo text not null,
  descripcion text,
  link_url text,
  fecha_publicacion date default current_date,
  activo boolean default true,
  orden integer default 0,
  created_at timestamptz default now()
);

create table public.eventos_calendario (
  id uuid primary key default gen_random_uuid(),
  titulo text not null,
  descripcion text,
  fecha_inicio timestamptz not null,
  fecha_fin timestamptz,
  ubicacion text,
  todo_el_dia boolean default false,
  created_at timestamptz default now()
);

create table public.permisos (
  user_id uuid primary key references public.profiles(id),
  predicacion boolean not null default false,
  reunion_publica boolean not null default false,
  limpieza boolean not null default false,
  anuncios boolean not null default false,
  calendario boolean not null default false,
  actualizado_at timestamptz default now(),
  vida_ministerio_escuela boolean not null default false,
  vida_ministerio_oraciones boolean not null default false,
  vida_ministerio_tareas boolean not null default false,
  secretario boolean not null default false
);

create table public.tareas_mecanicas (
  semana_id uuid primary key references public.semanas_vida_ministerio(id),
  audio_id uuid references public.publicadores(id),
  video_id uuid references public.publicadores(id),
  microfono1_inicio_id uuid references public.publicadores(id),
  microfono1_final_id uuid references public.publicadores(id),
  microfono2_inicio_id uuid references public.publicadores(id),
  microfono2_final_id uuid references public.publicadores(id),
  plataforma_inicio_id uuid references public.publicadores(id),
  plataforma_final_id uuid references public.publicadores(id),
  acomodador_entrada1_id uuid references public.publicadores(id),
  acomodador_entrada2_id uuid references public.publicadores(id),
  acomodador_audio_inicio_id uuid references public.publicadores(id),
  acomodador_audio_final_id uuid references public.publicadores(id),
  actualizado_at timestamptz default now()
);

create table public.tareas_mecanicas_reunion_publica (
  reunion_id uuid primary key references public.reuniones_publicas(id),
  audio_id uuid references public.publicadores(id),
  video_id uuid references public.publicadores(id),
  microfono1_inicio_id uuid references public.publicadores(id),
  microfono1_final_id uuid references public.publicadores(id),
  microfono2_inicio_id uuid references public.publicadores(id),
  microfono2_final_id uuid references public.publicadores(id),
  plataforma_inicio_id uuid references public.publicadores(id),
  plataforma_final_id uuid references public.publicadores(id),
  acomodador_entrada1_id uuid references public.publicadores(id),
  acomodador_entrada2_id uuid references public.publicadores(id),
  acomodador_audio_inicio_id uuid references public.publicadores(id),
  acomodador_audio_final_id uuid references public.publicadores(id),
  actualizado_at timestamptz default now()
);

create table public.wol_reuniones (
  id uuid primary key default gen_random_uuid(),
  codigo text not null,
  fecha_inicio date,
  url text not null,
  titulo text,
  html text,
  texto text,
  texto_normalizado text,
  procesada boolean not null default false,
  importada_en timestamptz not null default now(),
  idioma text not null default 'es'
);
comment on table public.wol_reuniones is 'Caché de reuniones de Vida y Ministerio importadas desde wol.jw.org. Guardado por la edge function wol-importar.';

create table public.informes_predicacion (
  id uuid primary key default gen_random_uuid(),
  publicador_id uuid references public.publicadores(id),
  mes integer not null check (mes >= 1 and mes <= 12),
  anio integer not null,
  precursor_auxiliar boolean not null default false,
  participo boolean not null default false,
  cursos_biblicos integer not null default 0,
  comentarios text,
  creado_en timestamptz not null default now(),
  horas integer,
  unique (publicador_id, mes, anio)
);

create table public.solicitudes_precursor_auxiliar (
  id uuid primary key default gen_random_uuid(),
  publicador_id uuid references public.publicadores(id),
  mes integer not null check (mes >= 1 and mes <= 12),
  anio integer not null,
  horas integer not null default 30 check (horas = any (array[15,30])),
  mes_hasta integer check (mes_hasta >= 1 and mes_hasta <= 12),
  anio_hasta integer,
  continuo boolean not null default false,
  creado_en timestamptz not null default now(),
  estado text not null default 'pendiente' check (estado = any (array['pendiente','aprobada','rechazada'])),
  revisado_por uuid references public.profiles(id),
  revisado_en timestamptz
);

create table public.territorios (
  id uuid primary key default gen_random_uuid(),
  numero integer not null unique,
  ultima_predicacion date,
  notas text,
  link_territorio text,
  link_mapa text,
  created_at timestamptz not null default now()
);
comment on column public.territorios.ultima_predicacion is 'Fecha en que el territorio fue predicado por última vez';

create table public.salidas_predicacion_territorios (
  salida_id uuid references public.salidas_predicacion(id),
  territorio_id uuid references public.territorios(id),
  primary key (salida_id, territorio_id)
);

-- Tabla de prueba de RLS (opcional, se puede omitir en el proyecto nuevo)
create table public._rls_test (
  id integer generated always as identity primary key,
  v text
);

-- ---------------------------------------------------------------------
-- 4. FUNCIONES
-- ---------------------------------------------------------------------

create or replace function public.rol_actual()
returns public.rol_usuario
language sql stable security definer set search_path to 'public'
as $$
  select rol from public.profiles where id = auth.uid();
$$;

create or replace function public.es_editor()
returns boolean
language sql stable security definer set search_path to 'public'
as $$
  select exists (
    select 1 from public.profiles
    where id = auth.uid() and rol in ('admin', 'anciano')
  );
$$;

create or replace function public.puede_editar(seccion text)
returns boolean
language sql stable security definer set search_path to 'public'
as $$
  select
    coalesce(
      (select rol = 'admin' from public.profiles where id = auth.uid()),
      false
    )
    or coalesce(
      (
        select p.aprobado and (
          case seccion
            when 'predicacion' then pe.predicacion
            when 'vida_ministerio_escuela' then pe.vida_ministerio_escuela
            when 'vida_ministerio_oraciones' then pe.vida_ministerio_oraciones
            when 'vida_ministerio_tareas' then pe.vida_ministerio_tareas
            when 'reunion_publica' then pe.reunion_publica
            when 'limpieza' then pe.limpieza
            when 'anuncios' then pe.anuncios
            when 'calendario' then pe.calendario
            when 'secretario' then pe.secretario
            else false
          end
        )
        from public.profiles p
        join public.permisos pe on pe.user_id = p.id
        where p.id = auth.uid()
      ),
      false
    );
$$;

create or replace function public.identificar_publicador(p_email text)
returns table(id uuid, nombre text, email text, activo boolean, grupo_id uuid)
language sql security definer set search_path to 'public'
as $$
  select id, nombre, email, activo, grupo_id
  from publicadores
  where activo = true and email is not null and lower(email) = lower(trim(p_email))
  limit 1;
$$;

create or replace function public.identificar_publicador_por_email(p_email text)
returns table(id uuid, nombre text, email text)
language sql stable security definer set search_path to 'public'
as $$
  select id, nombre, email
  from public.publicadores
  where activo = true
    and email is not null
    and lower(email) = lower(trim(p_email))
  limit 1;
$$;

create or replace function public.publicadores_publico()
returns table(id uuid, nombre text, servicio public.tipo_servicio_publicador)
language sql stable security definer set search_path to 'public'
as $$
  select id, nombre, servicio from public.publicadores where activo = true order by nombre;
$$;

create or replace function public.territorios_numeros_publico()
returns table(id uuid, numero integer)
language sql stable security definer set search_path to 'public'
as $$
  select id, numero from public.territorios order by numero;
$$;

create or replace function public.informes_estado(p_mes integer, p_anio integer)
returns table(
  publicador_id uuid, nombre text, email text, servicio public.tipo_servicio_publicador,
  grupo_id uuid, grupo_nombre text, informado boolean, precursor_auxiliar boolean,
  participo boolean, horas integer, cursos_biblicos integer, comentarios text, creado_en timestamptz
)
language plpgsql stable security definer set search_path to 'public'
as $$
begin
  if not public.puede_editar('secretario') then
    raise exception 'No autorizado';
  end if;

  return query
  select
    pub.id, pub.nombre, pub.email, pub.servicio, pub.grupo_id, g.nombre,
    (ip.id is not null) as informado,
    coalesce(ip.precursor_auxiliar, false),
    coalesce(ip.participo, false),
    ip.horas, ip.cursos_biblicos, ip.comentarios, ip.creado_en
  from public.publicadores pub
  left join public.grupos g on g.id = pub.grupo_id
  left join public.informes_predicacion ip
    on ip.publicador_id = pub.id and ip.mes = p_mes and ip.anio = p_anio
  where pub.activo = true
  order by pub.nombre;
end;
$$;

create or replace function public.enviar_informe_predicacion(
  p_publicador_id uuid, p_mes integer, p_anio integer, p_precursor_auxiliar boolean,
  p_participo boolean, p_cursos_biblicos integer, p_comentarios text, p_horas integer default null
)
returns void
language plpgsql security definer set search_path to 'public'
as $$
begin
  insert into public.informes_predicacion
    (publicador_id, mes, anio, precursor_auxiliar, participo, cursos_biblicos, comentarios, horas)
  values
    (p_publicador_id, p_mes, p_anio, p_precursor_auxiliar, p_participo, p_cursos_biblicos, p_comentarios, p_horas)
  on conflict (publicador_id, mes, anio) do update set
    precursor_auxiliar = excluded.precursor_auxiliar,
    participo = excluded.participo,
    cursos_biblicos = excluded.cursos_biblicos,
    comentarios = excluded.comentarios,
    horas = excluded.horas;
end;
$$;

-- Overload legado (sin p_horas) — se mantiene por compatibilidad con clientes viejos
create or replace function public.enviar_informe_predicacion(
  p_publicador_id uuid, p_mes integer, p_anio integer, p_precursor_auxiliar boolean,
  p_participo boolean, p_cursos_biblicos integer, p_comentarios text
)
returns void
language plpgsql security definer set search_path to 'public'
as $$
begin
  insert into public.informes_predicacion
    (publicador_id, mes, anio, precursor_auxiliar, participo, cursos_biblicos, comentarios)
  values
    (p_publicador_id, p_mes, p_anio, p_precursor_auxiliar, p_participo, p_cursos_biblicos, p_comentarios)
  on conflict (publicador_id, mes, anio) do update set
    precursor_auxiliar = excluded.precursor_auxiliar,
    participo = excluded.participo,
    cursos_biblicos = excluded.cursos_biblicos,
    comentarios = excluded.comentarios;
end;
$$;

create or replace function public.handle_new_user()
returns trigger
language plpgsql security definer set search_path to 'public'
as $$
declare
  hay_admin boolean;
  v_rol public.rol_usuario;
  v_servicio public.tipo_servicio_publicador;
  v_publicador_id uuid;
begin
  select exists(select 1 from public.profiles where rol = 'admin') into hay_admin;

  v_rol := (case when hay_admin then 'publicador' else 'admin' end)::public.rol_usuario;

  v_servicio := (case
                   when v_rol = 'anciano' then 'anciano'
                   when v_rol = 'siervo_ministerial' then 'siervo_ministerial'
                   else 'publicador'
                 end)::public.tipo_servicio_publicador;

  insert into public.publicadores (nombre, email, servicio)
  values (
    coalesce(new.raw_user_meta_data->>'nombre', new.email),
    new.email,
    v_servicio
  )
  returning id into v_publicador_id;

  insert into public.profiles (id, nombre, rol, aprobado, publicador_id)
  values (
    new.id,
    coalesce(new.raw_user_meta_data->>'nombre', new.email),
    v_rol,
    case when hay_admin then false else true end,
    v_publicador_id
  );

  insert into public.permisos (user_id) values (new.id);

  return new;
end;
$$;

create or replace function public.proteger_campos_profile()
returns trigger
language plpgsql security definer set search_path to 'public'
as $$
begin
  if public.rol_actual() <> 'admin' then
    new.rol := old.rol;
    new.aprobado := old.aprobado;
    new.grupo_id := old.grupo_id;
  end if;
  return new;
end;
$$;

create or replace function public.proteger_campos_semana()
returns trigger
language plpgsql security definer set search_path to 'public'
as $$
declare
  es_admin boolean;
  tiene_escuela boolean;
  tiene_oraciones boolean;
begin
  select rol = 'admin' into es_admin from public.profiles where id = auth.uid();
  if es_admin then
    return new;
  end if;

  tiene_escuela := public.puede_editar('vida_ministerio_escuela');
  tiene_oraciones := public.puede_editar('vida_ministerio_oraciones');

  if tiene_escuela and tiene_oraciones then
    return new;
  end if;

  if tiene_escuela and not tiene_oraciones then
    new.presidente_id := old.presidente_id;
    new.cantico_inicial := old.cantico_inicial;
    new.oracion_inicial_id := old.oracion_inicial_id;
    new.cantico_final := old.cantico_final;
    new.oracion_final_id := old.oracion_final_id;
  elsif tiene_oraciones and not tiene_escuela then
    new.lectura_biblia := old.lectura_biblia;
  end if;

  return new;
end;
$$;

-- ---- Funciones de recordatorios (usan pg_net para invocar la edge function "notificar") ----
-- IMPORTANTE: reemplazar 'REEMPLAZAR_CRON_SECRET' por un secreto nuevo generado por vos,
-- y 'REEMPLAZAR_PROJECT_REF' por el ref del proyecto nuevo, antes de ejecutar este bloque.
-- El mismo valor debe configurarse como secret CRON_SECRET en la edge function "notificar".

create or replace function public._enviar_recordatorios_informe_interno(p_mes integer, p_anio integer)
returns jsonb
language plpgsql security definer set search_path to 'public', 'extensions'
as $$
declare
  v_ids uuid[];
  cron_secret text := 'REEMPLAZAR_CRON_SECRET';
  function_url text := 'https://REEMPLAZAR_PROJECT_REF.supabase.co/functions/v1/notificar';
begin
  select array_agg(pub.id)
  into v_ids
  from public.publicadores pub
  where pub.activo = true
    and pub.email is not null
    and pub.email <> ''
    and not exists (
      select 1 from public.informes_predicacion ip
      where ip.publicador_id = pub.id and ip.mes = p_mes and ip.anio = p_anio
    );

  if v_ids is null or array_length(v_ids, 1) is null then
    return jsonb_build_object('destinatarios', 0, 'motivo', 'todos informaron o nadie activo tiene email cargado');
  end if;

  perform net.http_post(
    url := function_url,
    headers := jsonb_build_object('Content-Type','application/json','x-cron-secret',cron_secret),
    body := jsonb_build_object(
      'userIds', to_jsonb(v_ids),
      'asunto', 'Recordatorio: informe de predicación pendiente',
      'mensaje', 'Todavía no registramos tu informe de predicación del mes. Es importante que lo envíes cuanto antes desde la app, en la sección "Informe de Predicación". ¡Gracias por tu servicio!'
    )
  );

  return jsonb_build_object('destinatarios', array_length(v_ids, 1));
end;
$$;

create or replace function public.enviar_recordatorios_informe(p_mes integer, p_anio integer)
returns jsonb
language plpgsql security definer set search_path to 'public'
as $$
begin
  if not public.puede_editar('secretario') then
    raise exception 'No autorizado';
  end if;

  return public._enviar_recordatorios_informe_interno(p_mes, p_anio);
end;
$$;

create or replace function public.enviar_recordatorios_reunion_publica()
returns void
language plpgsql security definer set search_path to 'public', 'extensions'
as $$
declare
  reunion record;
  tareas record;
  cron_secret text := 'REEMPLAZAR_CRON_SECRET';
  function_url text := 'https://REEMPLAZAR_PROJECT_REF.supabase.co/functions/v1/notificar';
  tarea_labels jsonb := '{
    "audio_id": "Audio", "video_id": "Video",
    "microfono1_inicio_id": "Micrófono 1 inicio", "microfono2_inicio_id": "Micrófono 2 inicio",
    "microfono1_final_id": "Micrófono 1 final", "microfono2_final_id": "Micrófono 2 final",
    "plataforma_inicio_id": "Plataforma inicio", "plataforma_final_id": "Plataforma final",
    "acomodador_entrada1_id": "Acomodador entrada 1", "acomodador_entrada2_id": "Acomodador entrada 2",
    "acomodador_audio_inicio_id": "Acomodador aud. inicio", "acomodador_audio_final_id": "Acomodador aud. final"
  }'::jsonb;
  clave text;
  persona_id uuid;
begin
  select * into reunion from public.reuniones_publicas where fecha = current_date;
  if reunion.id is null then
    return;
  end if;

  if reunion.orador_id is not null then
    perform net.http_post(url := function_url, headers := jsonb_build_object('Content-Type','application/json','x-cron-secret',cron_secret),
      body := jsonb_build_object('userIds', jsonb_build_array(reunion.orador_id), 'asunto', 'Recordatorio: hoy das el discurso público', 'mensaje', 'Hoy tenés a tu cargo el discurso "' || coalesce(reunion.tema, '') || '" en la Reunión Pública.'));
  end if;
  if reunion.presidente_id is not null then
    perform net.http_post(url := function_url, headers := jsonb_build_object('Content-Type','application/json','x-cron-secret',cron_secret),
      body := jsonb_build_object('userIds', jsonb_build_array(reunion.presidente_id), 'asunto', 'Recordatorio: hoy presides la Reunión Pública', 'mensaje', 'Hoy tenés a tu cargo presidir la Reunión Pública.'));
  end if;
  if reunion.conductor_atalaya_id is not null then
    perform net.http_post(url := function_url, headers := jsonb_build_object('Content-Type','application/json','x-cron-secret',cron_secret),
      body := jsonb_build_object('userIds', jsonb_build_array(reunion.conductor_atalaya_id), 'asunto', 'Recordatorio: hoy conducís La Atalaya', 'mensaje', 'Hoy conducís el estudio de La Atalaya.'));
  end if;
  if reunion.lector_id is not null then
    perform net.http_post(url := function_url, headers := jsonb_build_object('Content-Type','application/json','x-cron-secret',cron_secret),
      body := jsonb_build_object('userIds', jsonb_build_array(reunion.lector_id), 'asunto', 'Recordatorio: hoy sos el lector', 'mensaje', 'Hoy tenés la lectura de La Atalaya.'));
  end if;

  select * into tareas from public.tareas_mecanicas_reunion_publica where reunion_id = reunion.id;
  if tareas.reunion_id is not null then
    for clave in select jsonb_object_keys(tarea_labels) loop
      execute format('select ($1).%I', clave) using tareas into persona_id;
      if persona_id is not null then
        perform net.http_post(url := function_url, headers := jsonb_build_object('Content-Type','application/json','x-cron-secret',cron_secret),
          body := jsonb_build_object('userIds', jsonb_build_array(persona_id), 'asunto', 'Recordatorio: tarea de hoy', 'mensaje', 'Hoy tenés la tarea "' || (tarea_labels->>clave) || '" en la Reunión Pública.'));
      end if;
    end loop;
  end if;
end;
$$;

create or replace function public.enviar_recordatorios_vida_ministerio()
returns void
language plpgsql security definer set search_path to 'public', 'extensions'
as $$
declare
  semana record;
  parte record;
  tareas record;
  cron_secret text := 'REEMPLAZAR_CRON_SECRET';
  function_url text := 'https://REEMPLAZAR_PROJECT_REF.supabase.co/functions/v1/notificar';
  tarea_labels jsonb := '{
    "audio_id": "Audio",
    "video_id": "Video",
    "microfono1_inicio_id": "Micrófono 1 inicio",
    "microfono2_inicio_id": "Micrófono 2 inicio",
    "microfono1_final_id": "Micrófono 1 final",
    "microfono2_final_id": "Micrófono 2 final",
    "plataforma_inicio_id": "Plataforma inicio",
    "plataforma_final_id": "Plataforma final",
    "acomodador_entrada1_id": "Acomodador entrada 1",
    "acomodador_entrada2_id": "Acomodador entrada 2",
    "acomodador_audio_inicio_id": "Acomodador aud. inicio",
    "acomodador_audio_final_id": "Acomodador aud. final"
  }'::jsonb;
  clave text;
  persona_id uuid;
begin
  select * into semana from public.semanas_vida_ministerio where fecha_inicio = current_date;
  if semana.id is null then
    return;
  end if;

  if semana.presidente_id is not null then
    perform net.http_post(
      url := function_url,
      headers := jsonb_build_object('Content-Type','application/json','x-cron-secret',cron_secret),
      body := jsonb_build_object('userIds', jsonb_build_array(semana.presidente_id), 'asunto', 'Recordatorio: hoy presides Vida y Ministerio', 'mensaje', 'Hoy tenés a tu cargo presidir el programa de Vida y Ministerio.')
    );
  end if;

  if semana.oracion_inicial_id is not null then
    perform net.http_post(
      url := function_url,
      headers := jsonb_build_object('Content-Type','application/json','x-cron-secret',cron_secret),
      body := jsonb_build_object('userIds', jsonb_build_array(semana.oracion_inicial_id), 'asunto', 'Recordatorio: hoy tenés la oración inicial', 'mensaje', 'Hoy te toca hacer la oración inicial en Vida y Ministerio.')
    );
  end if;

  if semana.oracion_final_id is not null then
    perform net.http_post(
      url := function_url,
      headers := jsonb_build_object('Content-Type','application/json','x-cron-secret',cron_secret),
      body := jsonb_build_object('userIds', jsonb_build_array(semana.oracion_final_id), 'asunto', 'Recordatorio: hoy tenés la oración final', 'mensaje', 'Hoy te toca hacer la oración final en Vida y Ministerio.')
    );
  end if;

  for parte in select * from public.partes_vida_ministerio where semana_id = semana.id loop
    if parte.asignado_id is not null then
      perform net.http_post(
        url := function_url,
        headers := jsonb_build_object('Content-Type','application/json','x-cron-secret',cron_secret),
        body := jsonb_build_object('userIds', jsonb_build_array(parte.asignado_id), 'asunto', 'Recordatorio: tenés una parte hoy', 'mensaje', 'Hoy tenés asignada la parte "' || parte.titulo || '" en Vida y Ministerio.')
      );
    end if;
    if parte.ayudante_id is not null then
      perform net.http_post(
        url := function_url,
        headers := jsonb_build_object('Content-Type','application/json','x-cron-secret',cron_secret),
        body := jsonb_build_object('userIds', jsonb_build_array(parte.ayudante_id), 'asunto', 'Recordatorio: sos ayudante hoy', 'mensaje', 'Hoy ayudás en la parte "' || parte.titulo || '" en Vida y Ministerio.')
      );
    end if;
  end loop;

  select * into tareas from public.tareas_mecanicas where semana_id = semana.id;
  if tareas.semana_id is not null then
    for clave in select jsonb_object_keys(tarea_labels) loop
      execute format('select ($1).%I', clave) using tareas into persona_id;
      if persona_id is not null then
        perform net.http_post(
          url := function_url,
          headers := jsonb_build_object('Content-Type','application/json','x-cron-secret',cron_secret),
          body := jsonb_build_object('userIds', jsonb_build_array(persona_id), 'asunto', 'Recordatorio: tarea de hoy', 'mensaje', 'Hoy tenés la tarea "' || (tarea_labels->>clave) || '" en la reunión.')
        );
      end if;
    end loop;
  end if;
end;
$$;

-- ---------------------------------------------------------------------
-- 5. TRIGGERS
-- ---------------------------------------------------------------------

create trigger trg_proteger_campos_profile
  before update on public.profiles
  for each row execute function public.proteger_campos_profile();

create trigger trg_proteger_campos_semana
  before update on public.semanas_vida_ministerio
  for each row execute function public.proteger_campos_semana();

-- Trigger sobre auth.users (requiere permisos de owner/supabase_admin; en el SQL Editor de Supabase funciona)
create trigger on_auth_user_created
  after insert on auth.users
  for each row execute function public.handle_new_user();

-- ---------------------------------------------------------------------
-- 6. RLS: habilitar en todas las tablas
-- ---------------------------------------------------------------------
alter table public.profiles enable row level security;
alter table public.config_congregacion enable row level security;
alter table public.grupos enable row level security;
alter table public.salidas_predicacion enable row level security;
alter table public.semanas_vida_ministerio enable row level security;
alter table public.partes_vida_ministerio enable row level security;
alter table public.reuniones_publicas enable row level security;
alter table public.turnos_limpieza enable row level security;
alter table public.anuncios enable row level security;
alter table public.eventos_calendario enable row level security;
alter table public.permisos enable row level security;
alter table public.tareas_mecanicas enable row level security;
alter table public.tareas_mecanicas_reunion_publica enable row level security;
alter table public.wol_reuniones enable row level security;
alter table public.informes_predicacion enable row level security;
alter table public.solicitudes_precursor_auxiliar enable row level security;
alter table public.publicadores enable row level security;
alter table public.territorios enable row level security;
alter table public.salidas_predicacion_territorios enable row level security;
alter table public._rls_test enable row level security;

-- ---------------------------------------------------------------------
-- 7. RLS POLICIES
-- ---------------------------------------------------------------------

-- profiles
create policy "Perfiles: admin gestiona todo" on public.profiles for all
  using (rol_actual() = 'admin');
create policy "Perfiles: cualquiera autenticado puede ver todos" on public.profiles for select
  using (auth.role() = 'authenticated');
create policy "Perfiles: publico puede ver nombre" on public.profiles for select
  to anon using (true);
create policy "Perfiles: usuario edita su propio nombre/telefono" on public.profiles for update
  using (auth.uid() = id);

-- config_congregacion
create policy "Config: lectura publica" on public.config_congregacion for select
  using (true);
create policy "Config: solo admin modifica" on public.config_congregacion for update
  using (rol_actual() = 'admin');

-- grupos
create policy "Grupos predicacion: lectura publica" on public.grupos for select
  using (true);
create policy "Grupos: lectura publica" on public.grupos for select
  using (true);
create policy "Grupos: solo admin gestiona" on public.grupos for all
  using (rol_actual() = 'admin');

-- salidas_predicacion
create policy "Salidas predicacion: lectura publica" on public.salidas_predicacion for select
  using (true);
create policy "Salidas predicacion: permiso granular" on public.salidas_predicacion for all
  using (puede_editar('predicacion'));

-- semanas_vida_ministerio
create policy "Semanas VM: lectura publica" on public.semanas_vida_ministerio for select
  using (true);
create policy "Semanas VM: escuela u oraciones pueden tocar la fila" on public.semanas_vida_ministerio for all
  using (puede_editar('vida_ministerio_escuela') or puede_editar('vida_ministerio_oraciones'));

-- partes_vida_ministerio
create policy "Partes VM: lectura publica" on public.partes_vida_ministerio for select
  using (true);
create policy "Partes VM: permisos mixtos por parte" on public.partes_vida_ministerio for all
  using (
    (seccion = 'ministerio' and puede_editar('vida_ministerio_escuela'))
    or (seccion = 'tesoros' and es_lectura_biblia = true and puede_editar('vida_ministerio_escuela'))
    or (seccion = 'tesoros' and es_lectura_biblia = false and puede_editar('vida_ministerio_oraciones'))
    or (seccion = 'vida_cristiana' and puede_editar('vida_ministerio_oraciones'))
  );

-- reuniones_publicas
create policy "Reunion publica: lectura publica" on public.reuniones_publicas for select
  using (true);
create policy "Reunion publica: permiso granular" on public.reuniones_publicas for all
  using (puede_editar('reunion_publica'));

-- turnos_limpieza
create policy "Limpieza: lectura publica" on public.turnos_limpieza for select
  using (true);
create policy "Limpieza: permiso granular" on public.turnos_limpieza for all
  using (puede_editar('limpieza'));

-- anuncios
create policy "Anuncios: lectura publica" on public.anuncios for select
  using (true);
create policy "Anuncios: permiso granular" on public.anuncios for all
  using (puede_editar('anuncios'));

-- eventos_calendario
create policy "Eventos: lectura publica" on public.eventos_calendario for select
  using (true);
create policy "Eventos: permiso granular" on public.eventos_calendario for all
  using (puede_editar('calendario'));

-- permisos
create policy "Permisos: admin ve y edita todos" on public.permisos for all
  using (rol_actual() = 'admin');
create policy "Permisos: el propio usuario ve los suyos" on public.permisos for select
  using (auth.uid() = user_id);

-- tareas_mecanicas
create policy "Tareas mecanicas: lectura publica" on public.tareas_mecanicas for select
  using (true);
create policy "Tareas mecanicas: permiso granular" on public.tareas_mecanicas for all
  using (puede_editar('vida_ministerio_tareas'));

-- tareas_mecanicas_reunion_publica
create policy "Tareas RP: lectura publica" on public.tareas_mecanicas_reunion_publica for select
  using (true);
create policy "Tareas RP: mismo permiso que tareas de VyM" on public.tareas_mecanicas_reunion_publica for all
  using (puede_editar('vida_ministerio_tareas'));

-- wol_reuniones
create policy "wol_reuniones_select_autenticados" on public.wol_reuniones for select
  to authenticated using (true);

-- informes_predicacion
create policy "Informes: cualquiera puede actualizar su envio" on public.informes_predicacion for update
  using (true);
create policy "Informes: cualquiera puede enviar" on public.informes_predicacion for insert
  with check (true);
create policy "Informes: lectura solo secretario" on public.informes_predicacion for select
  using (puede_editar('secretario'));

-- solicitudes_precursor_auxiliar
create policy "Solicitudes PA: cualquiera puede enviar" on public.solicitudes_precursor_auxiliar for insert
  with check (true);
create policy "Solicitudes PA: lectura solo secretario" on public.solicitudes_precursor_auxiliar for select
  using (puede_editar('secretario'));
create policy "Solicitudes PA: secretario revisa" on public.solicitudes_precursor_auxiliar for update
  using (puede_editar('secretario'));

-- publicadores
create policy "Publicadores: autenticados pueden ver activos" on public.publicadores for select
  to authenticated using (activo = true);
create policy "Publicadores: lectura publica limitada (nombre)" on public.publicadores for select
  to anon using (activo = true);
create policy "Publicadores: solo secretario gestiona" on public.publicadores for all
  using (puede_editar('secretario'));
create policy "Publicadores: solo secretario ve" on public.publicadores for select
  using (puede_editar('secretario'));

-- territorios
create policy "Territorios: lectura publica" on public.territorios for select
  to anon, authenticated using (true);
create policy "Territorios: permiso granular gestiona" on public.territorios for all
  using (puede_editar('predicacion')) with check (puede_editar('predicacion'));
create policy "Territorios: permiso granular ve" on public.territorios for select
  using (puede_editar('predicacion'));

-- salidas_predicacion_territorios
create policy "Salidas-territorios: lectura publica" on public.salidas_predicacion_territorios for select
  using (true);
create policy "Salidas-territorios: permiso granular gestiona" on public.salidas_predicacion_territorios for all
  using (puede_editar('predicacion')) with check (puede_editar('predicacion'));

-- _rls_test (opcional)
create policy "p_ins" on public._rls_test for insert
  with check (true);

-- ---------------------------------------------------------------------
-- 8. GRANTS
-- ---------------------------------------------------------------------
-- Patrón estándar de Supabase: anon/authenticated reciben privilegios a nivel
-- de tabla y RLS filtra las filas; en "publicadores" además se restringe el
-- acceso a columnas sensibles a nivel de columna para el rol anon.

grant usage on schema public to anon, authenticated;

grant all privileges on all tables in schema public to anon, authenticated;
grant all privileges on all sequences in schema public to anon, authenticated;
grant execute on all functions in schema public to anon, authenticated;

-- Restricción de columnas sensibles en publicadores para anon
revoke select on public.publicadores from anon;
grant select (id, activo, grupo_id, servicio, nombre) on public.publicadores to anon;
-- anon conserva insert/update/references en todas las columnas (heredado del grant general de arriba)

-- ---------------------------------------------------------------------
-- 9. CRON JOBS (pg_cron + pg_net contra la edge function "notificar")
-- ---------------------------------------------------------------------
-- Estos jobs llaman a funciones que a su vez usan net.http_post contra
-- REEMPLAZAR_PROJECT_REF (ver sección 4). Ajustar antes de correr esto.

select cron.schedule(
  'recordatorio-informe-mensual',
  '0 12 1 * *',
  $$select public._enviar_recordatorios_informe_interno(
      extract(month from (date_trunc('month', current_date) - interval '1 month'))::int,
      extract(year from (date_trunc('month', current_date) - interval '1 month'))::int
    );$$
);

select cron.schedule(
  'recordatorios-reunion-publica',
  '0 12 * * *',
  $$select public.enviar_recordatorios_reunion_publica();$$
);

select cron.schedule(
  'recordatorios-vida-ministerio',
  '0 12 * * *',
  $$select public.enviar_recordatorios_vida_ministerio();$$
);

-- ---------------------------------------------------------------------
-- 10. DATOS SEMILLA (opcional, recomendado)
-- ---------------------------------------------------------------------
-- config_congregacion requiere exactamente 1 fila (id=1). Sin esta fila
-- la app probablemente falle al leer configuración.
insert into public.config_congregacion (id, nombre)
values (1, 'Mi Congregación')
on conflict (id) do nothing;

-- =====================================================================
-- SECRETS A CONFIGURAR MANUALMENTE (no incluidos por seguridad)
-- =====================================================================
-- 1. Edge Function "notificar" (Project Settings -> Edge Functions -> Secrets,
--    o `supabase secrets set`):
--      GMAIL_USER            = tu correo de Gmail
--      GMAIL_APP_PASSWORD    = contraseña de aplicación de Google (16 caracteres)
--      CRON_SECRET            = un secreto random que vos generes, y que debe
--                                coincidir con el valor puesto en las funciones
--                                SQL de la sección 4 (reemplazar REEMPLAZAR_CRON_SECRET)
--
-- 2. Edge Function "wol-importar": no requiere secrets adicionales más allá
--    de los automáticos SUPABASE_URL / SUPABASE_ANON_KEY / SUPABASE_SERVICE_ROLE_KEY.
--
-- 3. Edge Function "gestionar-cuentas": tampoco requiere secrets adicionales,
--    usa las variables de entorno automáticas de Supabase.
--
-- 4. Antes de correr la sección 4 y 9 de este archivo, reemplazar:
--      REEMPLAZAR_CRON_SECRET   -> mismo valor que CRON_SECRET de arriba
--      REEMPLAZAR_PROJECT_REF   -> el ref del proyecto nuevo (ej: abcxyz123)
-- =====================================================================
