import { createClient } from "jsr:@supabase/supabase-js@2";

const corsHeaders = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Headers": "authorization, x-client-info, apikey, content-type",
  "Access-Control-Allow-Methods": "POST, OPTIONS",
};

function json(body: unknown, status = 200) {
  return new Response(JSON.stringify(body), {
    status,
    headers: { "Content-Type": "application/json", ...corsHeaders },
  });
}

Deno.serve(async (req: Request) => {
  if (req.method === "OPTIONS") {
    return new Response("ok", { headers: corsHeaders });
  }

  try {
    const authHeader = req.headers.get("Authorization");
    if (!authHeader) return json({ error: "No autorizado" }, 401);

    const supabaseAdmin = createClient(
      Deno.env.get("SUPABASE_URL")!,
      Deno.env.get("SUPABASE_SERVICE_ROLE_KEY")!
    );

    const token = authHeader.replace("Bearer ", "");
    const { data: { user }, error: authError } = await supabaseAdmin.auth.getUser(token);
    if (authError || !user) return json({ error: "No autorizado" }, 401);

    const { data: perfilSolicitante } = await supabaseAdmin
      .from("profiles")
      .select("rol")
      .eq("id", user.id)
      .maybeSingle();

    if (perfilSolicitante?.rol !== "admin") {
      return json({ error: "Solo un administrador puede gestionar cuentas" }, 403);
    }

    const body = await req.json();
    const { accion } = body;

    if (accion === "crear") {
      const { nombre, email, password } = body;
      if (!nombre?.trim() || !email?.trim() || !password) {
        return json({ error: "Faltan nombre, email o contraseña" }, 400);
      }
      if (password.length < 6) {
        return json({ error: "La contraseña debe tener al menos 6 caracteres" }, 400);
      }

      const { data, error } = await supabaseAdmin.auth.admin.createUser({
        email: email.trim(),
        password,
        email_confirm: true,
        user_metadata: { nombre: nombre.trim() },
      });

      if (error) {
        const msg = /already/i.test(error.message)
          ? "Ese correo ya está registrado."
          : error.message;
        return json({ error: msg }, 400);
      }

      await supabaseAdmin.from("profiles").update({ aprobado: true }).eq("id", data.user.id);

      return json({ ok: true, id: data.user.id });
    }

    if (accion === "eliminar") {
      const { userId } = body;
      if (!userId) return json({ error: "Falta userId" }, 400);
      if (userId === user.id) return json({ error: "No podés eliminar tu propia cuenta." }, 400);

      const { error } = await supabaseAdmin.auth.admin.deleteUser(userId);
      if (error) return json({ error: error.message }, 400);

      return json({ ok: true });
    }

    if (accion === "resetear_password") {
      const { userId, password } = body;
      if (!userId) return json({ error: "Falta userId" }, 400);
      if (!password || password.length < 6) {
        return json({ error: "La contraseña debe tener al menos 6 caracteres" }, 400);
      }

      const { error } = await supabaseAdmin.auth.admin.updateUserById(userId, { password });
      if (error) return json({ error: error.message }, 400);

      return json({ ok: true });
    }

    return json({ error: "Acción desconocida" }, 400);
  } catch (err) {
    console.error(err);
    return json({ error: String(err) }, 500);
  }
});
