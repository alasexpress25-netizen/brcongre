# Cómo recrear el proyecto Supabase de brcongre / congregacion-app

Este paquete tiene todo lo necesario para recrear el proyecto Supabase
(`hkqfaihwhyrfgshzhvue`) desde cero en un proyecto nuevo (por ejemplo para
otra congregación, o si migrás de cuenta).

```
schema.sql                          → esquema completo (tablas, enums,
                                       funciones, triggers, RLS, grants,
                                       cron jobs)
supabase/functions/
  ├── EDGE-FUNCTIONS.md             → detalle de las 3 edge functions
  ├── wol-importar/index.ts
  ├── notificar/index.ts
  └── gestionar-cuentas/index.ts
```

## Paso a paso

### 1. Crear el proyecto nuevo en Supabase
Dashboard → New Project. Anotá:
- **Project ID / Reference** (aparece en la URL del dashboard y en
  Settings → General, ej. `abcdxyzwvutsrqp`)
- **Project URL** (Settings → API, ej. `https://abcdxyzwvutsrqp.supabase.co`)
- **anon public key** (Settings → API)

### 2. Correr schema.sql
Antes de correrlo, abrí `schema.sql` y reemplazá `REEMPLAZAR_CRON_SECRET`
(3 ocurrencias, en las funciones `enviar_recordatorios_*`) por un secreto
nuevo generado por vos, por ejemplo:
```bash
openssl rand -base64 32
```
Guardá ese valor — lo vas a necesitar en el paso 4 también.

Luego corré el archivo completo en el **SQL Editor** del proyecto nuevo, o
vía Supabase CLI:
```bash
supabase db push --project-ref TU_PROJECT_ID
# o directamente:
psql "postgresql://postgres:[PASSWORD]@db.TU_PROJECT_ID.supabase.co:5432/postgres" -f schema.sql
```

### 3. Desplegar las Edge Functions
Ver el detalle completo en `supabase/functions/EDGE-FUNCTIONS.md`. Resumen:
```bash
supabase functions deploy wol-importar --project-ref TU_PROJECT_ID
supabase functions deploy notificar --project-ref TU_PROJECT_ID --no-verify-jwt
supabase functions deploy gestionar-cuentas --project-ref TU_PROJECT_ID --no-verify-jwt
```

### 4. Configurar los secrets manuales
Estos **no** se pueden generar con SQL, hay que crearlos a mano:

| Secret | Dónde se configura | Cómo se obtiene |
|---|---|---|
| `SMTP_HOST` | `supabase secrets set` (Edge Functions) | `smtp.gmail.com` si usás Gmail |
| `SMTP_PORT` | ídem | `465` |
| `SMTP_USER` | ídem | la cuenta de Gmail que envía los correos |
| `SMTP_PASSWORD` | ídem | **Contraseña de aplicación de Google** — sí, es esta. Se crea en la cuenta de Google que envía los correos: Seguridad → Verificación en 2 pasos → Contraseñas de aplicaciones (requiere 2FA activo en esa cuenta) |
| `CRON_SECRET` | hardcodeado en `notificar/index.ts` (no es un secret de Supabase) | el mismo valor random que generaste y pegaste en `schema.sql` en el paso 2 |

```bash
supabase secrets set SMTP_HOST=smtp.gmail.com --project-ref TU_PROJECT_ID
supabase secrets set SMTP_PORT=465 --project-ref TU_PROJECT_ID
supabase secrets set SMTP_USER=tuiglesia@gmail.com --project-ref TU_PROJECT_ID
supabase secrets set SMTP_PASSWORD="xxxx xxxx xxxx xxxx" --project-ref TU_PROJECT_ID
```

Después de generar el `CRON_SECRET`, editá `notificar/index.ts`, reemplazá
`REEMPLAZAR_CRON_SECRET` por el valor real, y volvé a desplegar esa función.

`SUPABASE_URL` y `SUPABASE_SERVICE_ROLE_KEY` **no** hace falta configurarlos:
Supabase los inyecta automáticamente en toda Edge Function del proyecto.

### 5. Dónde reemplazar el Project ID y la anon key en el código

Buscando en todo el repo, el **único lugar** donde el frontend usa estos
valores es a través de variables de entorno (`src/lib/supabaseClient.js` ya
las lee de `import.meta.env`, no hay nada hardcodeado en el código fuente).
Así que solo hay que tocar el `.env`:

**Archivo: `.env`** (en la raíz del proyecto, al lado de `package.json`)
```env
VITE_SUPABASE_URL=https://TU_PROJECT_ID.supabase.co
VITE_SUPABASE_ANON_KEY=tu-anon-key-nueva
```

Si el proyecto está desplegado en **Vercel**, además hay que actualizar las
mismas dos variables en:
`Vercel → Project → Settings → Environment Variables` → `VITE_SUPABASE_URL`
y `VITE_SUPABASE_ANON_KEY` → y volver a hacer deploy (o "Redeploy") para que
tomen el nuevo valor, ya que Vite las inyecta en build time.

No hay ningún otro archivo (`vercel.json`, `package.json`, etc.) que
referencie el project ID o la key — confirmé con una búsqueda completa del
repo.

### 6. (Opcional) Fila inicial de config_congregacion
`schema.sql` incluye, comentado, un `INSERT` inicial para la tabla
`config_congregacion` (tiene un `CHECK (id = 1)`, así que solo puede existir
una fila). Descomentalo y ajustá los valores si tu app depende de que exista
esa fila desde el arranque.

---

## Resumen de qué es manual vs. automático

| Elemento | ¿Se recrea con schema.sql? |
|---|---|
| Tablas, enums, funciones, triggers, RLS, grants, cron jobs | ✅ Sí |
| Edge Functions (código) | ✅ Sí, están en `supabase/functions/` |
| `SUPABASE_URL` / `SUPABASE_SERVICE_ROLE_KEY` en Edge Functions | ✅ Automático (Supabase los inyecta) |
| `SMTP_HOST` / `SMTP_PORT` / `SMTP_USER` / `SMTP_PASSWORD` | ❌ Manual (paso 4) |
| `CRON_SECRET` | ❌ Manual, en 2 lugares (schema.sql + notificar/index.ts) |
| `VITE_SUPABASE_URL` / `VITE_SUPABASE_ANON_KEY` (frontend) | ❌ Manual, en `.env` (y Vercel si aplica) |
