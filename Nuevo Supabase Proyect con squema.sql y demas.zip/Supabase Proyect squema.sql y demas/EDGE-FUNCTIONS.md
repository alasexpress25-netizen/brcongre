# Edge Functions — brcongre / VidaMinisterio

Este proyecto usa 3 Edge Functions en Supabase. El código de las 3 está en esta
carpeta, listo para desplegar en el proyecto nuevo.

```
supabase/functions/
├── wol-importar/       (ya estaba en el repo)
├── notificar/          (extraída del proyecto vivo, no estaba en el repo)
└── gestionar-cuentas/  (extraída del proyecto vivo, no estaba en el repo)
```

> `notificar` y `gestionar-cuentas` no estaban en el .zip del repo — solo
> existían desplegadas en el proyecto Supabase original. Las recuperé
> directamente desde ahí para que puedas reconstruir el proyecto completo.

---

## 1. wol-importar

**Qué hace:** scrapea la Biblioteca en Línea Watchtower (WOL) con Cheerio y
carga el contenido de las reuniones en la tabla `wol_reuniones`.

- **verify_jwt:** `true` (requiere estar logueado para invocarla)
- **Secrets:** ninguno propio. Solo usa `SUPABASE_URL` y
  `SUPABASE_SERVICE_ROLE_KEY`, que Supabase inyecta automáticamente en toda
  Edge Function — no hay que configurarlos a mano.
- **Deploy:**
  ```bash
  supabase functions deploy wol-importar --project-ref TU_PROJECT_ID
  ```

## 2. notificar

**Qué hace:** envía emails (recordatorios, notificaciones manuales del
admin) vía SMTP. La llaman tanto el frontend (admin logueado) como
`pg_cron` desde la base de datos (llamada "interna", autenticada con un
secreto compartido en vez de un JWT de usuario).

- **verify_jwt:** `false` (la función maneja su propia autorización interna:
  admin logueado *o* secreto de cron — ver código)
- **Secrets a configurar manualmente:**

  | Secret | Descripción | Ejemplo |
  |---|---|---|
  | `SMTP_HOST` | Servidor SMTP saliente | `smtp.gmail.com` |
  | `SMTP_PORT` | Puerto SMTP | `465` |
  | `SMTP_USER` | Cuenta que envía los correos | `tuiglesia@gmail.com` |
  | `SMTP_PASSWORD` | **Contraseña de aplicación de Google** (no la contraseña normal de la cuenta) | `abcd efgh ijkl mnop` |

  Sí — la "contraseña de app de Google" que mencionás es exactamente esta:
  `SMTP_PASSWORD`. Se genera en la cuenta de Google que envía los correos,
  en *Gestionar tu cuenta de Google → Seguridad → Verificación en 2 pasos →
  Contraseñas de aplicaciones*. Requiere que esa cuenta tenga la
  verificación en 2 pasos activada.

  ```bash
  supabase secrets set SMTP_HOST=smtp.gmail.com --project-ref TU_PROJECT_ID
  supabase secrets set SMTP_PORT=465 --project-ref TU_PROJECT_ID
  supabase secrets set SMTP_USER=tuiglesia@gmail.com --project-ref TU_PROJECT_ID
  supabase secrets set SMTP_PASSWORD="abcd efgh ijkl mnop" --project-ref TU_PROJECT_ID
  ```

- **`CRON_SECRET` (dentro del código, no es un secret de Supabase):**
  En `index.ts` hay una constante `CRON_SECRET` con el placeholder
  `REEMPLAZAR_CRON_SECRET`. Este valor:
  1. Lo generás vos (cualquier string random largo, ej. con
     `openssl rand -base64 32`).
  2. Lo pegás en `notificar/index.ts` reemplazando `REEMPLAZAR_CRON_SECRET`.
  3. Lo pegás **exactamente igual** en `schema.sql`, en las 3 funciones
     `enviar_recordatorios_*` (buscá `REEMPLAZAR_CRON_SECRET` ahí también —
     hay 3 ocurrencias de la variable `cron_secret`).

  Es un secreto compartido entre Postgres (que llama a la función vía
  `pg_cron` + `pg_net`) y la función misma — por eso no puede ser un
  "secret" de Supabase (Postgres no tiene forma de leer esos), tiene que
  quedar embebido en ambos lados.

- **Deploy:**
  ```bash
  supabase functions deploy notificar --project-ref TU_PROJECT_ID --no-verify-jwt
  ```

## 3. gestionar-cuentas

**Qué hace:** crear cuentas de login, eliminar cuentas y resetear
contraseñas, todo restringido a admins. Usa `service_role` para las
operaciones de `auth.admin.*`.

- **verify_jwt:** `false` (la función valida el JWT del usuario a mano y
  chequea `rol = 'admin'` en `profiles`)
- **Secrets:** ninguno propio, solo `SUPABASE_URL` y
  `SUPABASE_SERVICE_ROLE_KEY` (automáticos).
- **Deploy:**
  ```bash
  supabase functions deploy gestionar-cuentas --project-ref TU_PROJECT_ID --no-verify-jwt
  ```

---

## Orden recomendado para recrear el proyecto

1. Crear el proyecto nuevo en Supabase.
2. Correr `schema.sql` (reemplazando `REEMPLAZAR_CRON_SECRET` ahí primero).
3. Desplegar las 3 Edge Functions (comandos arriba).
4. Configurar los secrets de `notificar` (tabla SMTP arriba).
5. Actualizar `CRON_SECRET` en `notificar/index.ts` con el mismo valor que
   pusiste en `schema.sql`, y volver a desplegar `notificar`.
6. Actualizar `.env` del frontend — ver `README-MIGRACION.md`.
